<?php
// ============================================================
// admin_tiket.php — CRUD Kategori Tiket (Admin)
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); exit;
}

$pesan = "";

// HAPUS
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    // Cek apakah tiket dipakai di transaksi
    $cek = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS c FROM tb_transaksi WHERE id_tiket = $id"));
    if ($cek['c'] > 0) {
        $pesan = "<div class='alert alert-danger'><i class='bi bi-exclamation-triangle me-2'></i>Tiket tidak bisa dihapus karena sudah ada dalam transaksi.</div>";
    } else {
        mysqli_query($koneksi, "DELETE FROM tb_tiket WHERE id_tiket = $id");
        $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Tiket berhasil dihapus.</div>";
    }
}

// SIMPAN (tambah / update)
if (isset($_POST['simpan'])) {
    $id        = (int)   $_POST['id'];
    $kategori  = trim(mysqli_real_escape_string($koneksi, $_POST['kategori']  ?? ''));
    $harga     = (int)   $_POST['harga'];
    $deskripsi = trim(mysqli_real_escape_string($koneksi, $_POST['deskripsi'] ?? ''));

    if ($kategori === '' || $harga <= 0) {
        $pesan = "<div class='alert alert-warning'>Kategori dan harga harus diisi dengan benar.</div>";
    } elseif ($id === 0) {
        mysqli_query($koneksi, "INSERT INTO tb_tiket (kategori, harga, deskripsi) VALUES ('$kategori', $harga, '$deskripsi')");
        $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Tiket baru berhasil ditambahkan.</div>";
    } else {
        mysqli_query($koneksi, "UPDATE tb_tiket SET kategori='$kategori', harga=$harga, deskripsi='$deskripsi' WHERE id_tiket=$id");
        $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Tiket berhasil diperbarui.</div>";
    }
}

// AMBIL DATA EDIT
$edit = ['id_tiket' => '', 'kategori' => '', 'harga' => '', 'deskripsi' => ''];
if (isset($_GET['edit'])) {
    $id   = (int) $_GET['edit'];
    $row  = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM tb_tiket WHERE id_tiket = $id"));
    if ($row) $edit = $row;
}

// DAFTAR TIKET
$tiket_list = mysqli_query($koneksi, "SELECT * FROM tb_tiket ORDER BY id_tiket ASC");
?>
<?php include 'navbar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold mb-0"><i class="bi bi-ticket-perforated me-2 text-primary"></i>Manajemen Tiket</h4>
</div>

<?= $pesan ?>

<div class="row g-4">
    <!-- FORM -->
    <div class="col-md-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white fw-semibold">
                <?= $edit['id_tiket'] ? '<i class="bi bi-pencil me-1"></i>Edit Tiket' : '<i class="bi bi-plus-circle me-1"></i>Tambah Tiket Baru' ?>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="id" value="<?= $edit['id_tiket'] ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Kategori Tiket</label>
                        <input type="text" name="kategori" class="form-control"
                               placeholder="cth: Umum Dewasa"
                               value="<?= htmlspecialchars($edit['kategori']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Harga (Rp)</label>
                        <input type="number" name="harga" class="form-control" min="1"
                               placeholder="cth: 15000"
                               value="<?= $edit['harga'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Deskripsi <small class="text-muted">(opsional)</small></label>
                        <textarea name="deskripsi" class="form-control" rows="2"
                                  placeholder="Keterangan tiket"><?= htmlspecialchars($edit['deskripsi']) ?></textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="simpan" class="btn btn-primary flex-fill">
                            <i class="bi bi-save me-1"></i> Simpan
                        </button>
                        <?php if ($edit['id_tiket']): ?>
                            <a href="admin_tiket.php" class="btn btn-outline-secondary">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- TABEL -->
    <div class="col-md-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white border-0 pt-3">
                <h6 class="fw-bold mb-0">Daftar Kategori Tiket</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Deskripsi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; while ($r = mysqli_fetch_assoc($tiket_list)): ?>
                            <tr <?= $edit['id_tiket'] == $r['id_tiket'] ? 'class="table-warning"' : '' ?>>
                                <td><?= $no++ ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($r['kategori']) ?></td>
                                <td class="text-success fw-semibold">Rp <?= number_format($r['harga'], 0, ',', '.') ?></td>
                                <td><small class="text-muted"><?= htmlspecialchars($r['deskripsi'] ?? '-') ?></small></td>
                                <td>
                                    <a href="?edit=<?= $r['id_tiket'] ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="?hapus=<?= $r['id_tiket'] ?>" class="btn btn-danger btn-sm"
                                       onclick="return confirm('Hapus tiket ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
