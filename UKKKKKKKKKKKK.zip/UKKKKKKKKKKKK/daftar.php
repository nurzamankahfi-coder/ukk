<?php
// ============================================================
// daftar.php — Registrasi Customer Baru
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';

if (isset($_SESSION['id_user'])) {
    header("Location: pesan_tiket.php");
    exit;
}

$error   = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim(mysqli_real_escape_string($koneksi, $_POST['nama']     ?? ''));
    $username = trim(mysqli_real_escape_string($koneksi, $_POST['username'] ?? ''));
    $password = $_POST['password'] ?? '';
    $konfirm  = $_POST['konfirm']  ?? '';

    if ($nama === '' || $username === '' || $password === '') {
        $error = "Semua kolom harus diisi.";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter.";
    } elseif ($password !== $konfirm) {
        $error = "Konfirmasi password tidak cocok.";
    } else {
        // Cek username sudah dipakai
        $cek = mysqli_query($koneksi, "SELECT id_user FROM tb_user WHERE username = '$username'");
        if (mysqli_num_rows($cek) > 0) {
            $error = "Username sudah digunakan, pilih username lain.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            mysqli_query($koneksi, "INSERT INTO tb_user (nama, username, pass, role)
                                    VALUES ('$nama', '$username', '$hash', 'customer')");
            $success = "Akun berhasil dibuat! Silakan login.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Akun — Kolam Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card { border: none; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.25); max-width: 460px; width: 100%; }
        .card-header { background: linear-gradient(135deg, #0ea5e9, #0369a1); color: white; border-radius: 16px 16px 0 0 !important; text-align: center; padding: 28px; }
        .btn-daftar { background: linear-gradient(135deg, #0ea5e9, #0369a1); border: none; font-weight: 600; }
        .btn-daftar:hover { opacity: 0.9; color: white; }
    </style>
</head>
<body>
<div class="card">
    <div class="card-header">
        <i class="bi bi-person-plus-fill fs-1 d-block mb-1"></i>
        <h5 class="fw-bold mb-0">Buat Akun Baru</h5>
    </div>
    <div class="card-body p-4">
        <?php if ($success): ?>
            <div class="alert alert-success"><i class="bi bi-check-circle me-2"></i><?= $success ?>
                <a href="login.php" class="alert-link ms-2">Login sekarang →</a>
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Nama Lengkap</label>
                <input type="text" name="nama" class="form-control"
                       value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Username</label>
                <input type="text" name="username" class="form-control"
                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Password</label>
                <input type="password" name="password" class="form-control" minlength="6" required>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Konfirmasi Password</label>
                <input type="password" name="konfirm" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-daftar btn-primary w-100 py-2">
                <i class="bi bi-person-check me-1"></i> Daftar
            </button>
        </form>
        <hr>
        <p class="text-center text-muted small mb-0">
            Sudah punya akun? <a href="login.php" class="fw-semibold text-decoration-none">Login</a>
        </p>
    </div>
</div>
</body>
</html>
