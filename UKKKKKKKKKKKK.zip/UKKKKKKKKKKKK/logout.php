<?php
// ============================================================
// logout.php — Keluar dari sistem
// ============================================================
session_start();
session_unset();
session_destroy();
header("Location: login.php");
exit;
