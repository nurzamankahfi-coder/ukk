<?php
// ============================================================
// footer.php — Footer yang dipakai semua halaman
// ============================================================
?>
</div><!-- /.container -->
<div class="footer">
    <i class="bi bi-water me-1"></i> Sistem Tiket Kolam Renang &copy; <?= date('Y') ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
