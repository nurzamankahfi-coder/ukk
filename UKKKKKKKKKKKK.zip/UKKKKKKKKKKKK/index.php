<?php
// ============================================================
// index.php — Entry point, redirect sesuai status login
// ============================================================
session_start();
if (isset($_SESSION['id_user'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin_dashboard.php");
    } else {
        header("Location: pesan_tiket.php");
    }
} else {
    header("Location: login.php");
}
exit;
