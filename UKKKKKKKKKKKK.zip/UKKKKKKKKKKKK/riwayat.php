<?php
// ============================================================
// riwayat.php — Riwayat Pemesanan Tiket (Customer)
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php"); exit;
}
if ($_SESSION['role'] === 'admin') {
    header("Location: admin_transaksi.php"); exit;
}

$id_user = (int) $_SESSION['id_user'];
$pesan   = "";

// HAPUS
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    // Pastikan hanya bisa hapus milik sendiri
    $cek = mysqli_fetch_assoc(mysqli_query($koneksi,
        "SELECT id_transaksi FROM tb_transaksi WHERE id_transaksi=$id AND id_user=$id_user"));
    if ($cek) {
        mysqli_query($koneksi, "DELETE FROM tb_transaksi WHERE id_transaksi=$id AND id_user=$id_user");
        $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Transaksi berhasil dihapus.</div>";
    } else {
        $pesan = "<div class='alert alert-danger'><i class='bi bi-x-circle me-2'></i>Transaksi tidak ditemukan.</div>";
    }
}

// UPDATE (simpan edit)
if (isset($_POST['simpan'])) {
    $id        = (int) $_POST['id'];
    $id_tiket  = (int) $_POST['id_tiket'];
    $jml_tiket = (int) $_POST['jml_tiket'];

    // Pastikan hanya bisa edit milik sendiri
    $cek = mysqli_fetch_assoc(mysqli_query($koneksi,
        "SELECT id_transaksi FROM tb_transaksi WHERE id_transaksi=$id AND id_user=$id_user"));

    if (!$cek) {
        $pesan = "<div class='alert alert-danger'><i class='bi bi-x-circle me-2'></i>Transaksi tidak ditemukan.</div>";
    } elseif ($jml_tiket < 1 || $jml_tiket > 20) {
        $pesan = "<div class='alert alert-warning'><i class='bi bi-exclamation-triangle me-2'></i>Jumlah tiket harus antara 1–20.</div>";
    } else {
        $tiket_row = mysqli_fetch_assoc(mysqli_query($koneksi,
            "SELECT harga FROM tb_tiket WHERE id_tiket=$id_tiket"));
        if ($tiket_row) {
            $total = (int) $tiket_row['harga'] * $jml_tiket;
            mysqli_query($koneksi,
                "UPDATE tb_transaksi
                 SET id_tiket=$id_tiket, jml_tiket=$jml_tiket, total_harga=$total
                 WHERE id_transaksi=$id AND id_user=$id_user");
            $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Transaksi berhasil diperbarui.</div>";
        } else {
            $pesan = "<div class='alert alert-danger'><i class='bi bi-x-circle me-2'></i>Kategori tiket tidak ditemukan.</div>";
        }
    }
}

// DATA EDIT
$edit = null;
if (isset($_GET['edit'])) {
    $id   = (int) $_GET['edit'];
    $edit = mysqli_fetch_assoc(mysqli_query($koneksi,
        "SELECT t.*, k.kategori FROM tb_transaksi t
         JOIN tb_tiket k ON t.id_tiket = k.id_tiket
         WHERE t.id_transaksi=$id AND t.id_user=$id_user"));
}

// Daftar tiket untuk dropdown
$tiket_options = [];
$qt = mysqli_query($koneksi, "SELECT * FROM tb_tiket ORDER BY kategori ASC");
while ($r = mysqli_fetch_assoc($qt)) $tiket_options[] = $r;

// DATA RIWAYAT
$riwayat = mysqli_query($koneksi,
    "SELECT t.*, k.kategori, k.harga AS harga_satuan
     FROM tb_transaksi t
     JOIN tb_tiket k ON t.id_tiket = k.id_tiket
     WHERE t.id_user = $id_user
     ORDER BY t.id_transaksi DESC");

$stat = mysqli_fetch_assoc(mysqli_query($koneksi,
    "SELECT COUNT(*) AS cnt, SUM(total_harga) AS total, SUM(jml_tiket) AS jml
     FROM tb_transaksi WHERE id_user = $id_user"));
?>
<?php include 'navbar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Riwayat Pemesanan</h4>
    <a href="pesan_tiket.php" class="btn btn-primary btn-sm">
        <i class="bi bi-plus-circle me-1"></i> Pesan Tiket Baru
    </a>
</div>

<?= $pesan ?>

<?php if ($edit): ?>
<!-- Modal Edit -->
<div class="modal fade show d-block" tabindex="-1" style="background:rgba(0,0,0,0.5)">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-pencil-square me-2"></i>Edit Transaksi
                </h5>
                <a href="riwayat.php" class="btn-close"></a>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $edit['id_transaksi'] ?>">

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Kategori Tiket</label>
                        <select name="id_tiket" class="form-select" required id="editTiket" onchange="updatePreview()">
                            <?php foreach ($tiket_options as $t): ?>
                            <option value="<?= $t['id_tiket'] ?>"
                                    data-harga="<?= $t['harga'] ?>"
                                    <?= $t['id_tiket'] == $edit['id_tiket'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($t['kategori']) ?> — Rp <?= number_format($t['harga'], 0, ',', '.') ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Jumlah Tiket <small class="text-muted">(maks. 20)</small></label>
                        <input type="number" name="jml_tiket" id="editJml" class="form-control"
                               min="1" max="20" value="<?= $edit['jml_tiket'] ?>"
                               required oninput="updatePreview()">
                    </div>
                    <div class="alert alert-info d-flex justify-content-between align-items-center py-2 mb-0">
                        <span><i class="bi bi-calculator me-2"></i>Estimasi Total:</span>
                        <strong id="editPreview" class="fs-5 text-primary">
                            Rp <?= number_format($edit['total_harga'], 0, ',', '.') ?>
                        </strong>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="riwayat.php" class="btn btn-outline-secondary">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-warning fw-semibold">
                        <i class="bi bi-save me-1"></i>Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
function updatePreview() {
    const sel   = document.getElementById('editTiket');
    const jml   = parseInt(document.getElementById('editJml').value) || 0;
    const opt   = sel.options[sel.selectedIndex];
    const harga = opt ? parseInt(opt.dataset.harga || 0) : 0;
    document.getElementById('editPreview').textContent =
        'Rp ' + (harga * jml).toLocaleString('id-ID');
}
</script>
<?php endif; ?>

<!-- Statistik pribadi -->
<div class="row g-3 mb-4">
    <div class="col-4">
        <div class="card border-0 shadow-sm text-center py-3" style="border-top:4px solid #0ea5e9!important">
            <div class="fs-2 fw-bold text-primary"><?= $stat['cnt'] ?? 0 ?></div>
            <div class="text-muted small">Total Transaksi</div>
        </div>
    </div>
    <div class="col-4">
        <div class="card border-0 shadow-sm text-center py-3" style="border-top:4px solid #22c55e!important">
            <div class="fs-2 fw-bold text-success"><?= $stat['jml'] ?? 0 ?></div>
            <div class="text-muted small">Total Tiket</div>
        </div>
    </div>
    <div class="col-4">
        <div class="card border-0 shadow-sm text-center py-3" style="border-top:4px solid #f59e0b!important">
            <div class="fs-6 fw-bold text-warning">Rp <?= number_format($stat['total'] ?? 0, 0, ',', '.') ?></div>
            <div class="text-muted small">Total Bayar</div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Kategori Tiket</th>
                        <th>Harga Satuan</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; $found = false; while ($r = mysqli_fetch_assoc($riwayat)):
                        $found = true; ?>
                    <tr <?= $edit && $edit['id_transaksi'] == $r['id_transaksi'] ? 'class="table-warning"' : '' ?>>
                        <td><?= $no++ ?></td>
                        <td><span class="badge bg-primary"><?= htmlspecialchars($r['kategori']) ?></span></td>
                        <td class="text-muted">Rp <?= number_format($r['harga_satuan'], 0, ',', '.') ?></td>
                        <td><span class="badge bg-secondary"><?= $r['jml_tiket'] ?>x</span></td>
                        <td class="text-success fw-bold">Rp <?= number_format($r['total_harga'], 0, ',', '.') ?></td>
                        <td><small class="text-muted"><?= !empty($r['tgl_pesan']) ? date('d/m/Y H:i', strtotime($r['tgl_pesan'])) : '<span class="text-muted">-</span>' ?></small></td>
                        <td>
                            <a href="?edit=<?= $r['id_transaksi'] ?>" class="btn btn-warning btn-sm" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <a href="?hapus=<?= $r['id_transaksi'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                               onclick="return confirm('Hapus transaksi ini?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (!$found): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            <i class="bi bi-ticket fs-1 d-block mb-2 opacity-25"></i>
                            Belum ada riwayat pemesanan.
                            <br><a href="pesan_tiket.php" class="btn btn-primary btn-sm mt-2">Pesan Tiket Sekarang</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
