<?php
// ============================================================
// admin_user.php — CRUD Pengguna (Admin)
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); exit;
}

$pesan = "";

// HAPUS
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    if ($id === (int) $_SESSION['id_user']) {
        $pesan = "<div class='alert alert-danger'>Tidak bisa menghapus akun diri sendiri.</div>";
    } else {
        mysqli_query($koneksi, "DELETE FROM tb_user WHERE id_user = $id");
        $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Pengguna berhasil dihapus.</div>";
    }
}

// SIMPAN (tambah / update)
if (isset($_POST['simpan'])) {
    $id       = (int)   $_POST['id'];
    $nama     = trim(mysqli_real_escape_string($koneksi, $_POST['nama']     ?? ''));
    $username = trim(mysqli_real_escape_string($koneksi, $_POST['username'] ?? ''));
    $role     = in_array($_POST['role'], ['admin','customer']) ? $_POST['role'] : 'customer';
    $password = $_POST['password'] ?? '';

    if ($nama === '' || $username === '') {
        $pesan = "<div class='alert alert-warning'>Nama dan username harus diisi.</div>";
    } elseif ($id === 0) {
        // Tambah baru
        if ($password === '') {
            $pesan = "<div class='alert alert-warning'>Password harus diisi untuk pengguna baru.</div>";
        } else {
            $cek = mysqli_query($koneksi, "SELECT id_user FROM tb_user WHERE username = '$username'");
            if (mysqli_num_rows($cek) > 0) {
                $pesan = "<div class='alert alert-danger'>Username sudah digunakan.</div>";
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                mysqli_query($koneksi, "INSERT INTO tb_user (nama, username, pass, role)
                                        VALUES ('$nama', '$username', '$hash', '$role')");
                $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Pengguna berhasil ditambahkan.</div>";
            }
        }
    } else {
        // Update
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            mysqli_query($koneksi, "UPDATE tb_user SET nama='$nama', username='$username', pass='$hash', role='$role' WHERE id_user=$id");
        } else {
            mysqli_query($koneksi, "UPDATE tb_user SET nama='$nama', username='$username', role='$role' WHERE id_user=$id");
        }
        $pesan = "<div class='alert alert-success'><i class='bi bi-check-circle me-2'></i>Pengguna berhasil diperbarui.</div>";
    }
}

// EDIT
$edit = ['id_user' => '', 'nama' => '', 'username' => '', 'role' => 'customer'];
if (isset($_GET['edit'])) {
    $id  = (int) $_GET['edit'];
    $row = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM tb_user WHERE id_user = $id"));
    if ($row) $edit = $row;
}

$users = mysqli_query($koneksi, "SELECT u.*, (SELECT COUNT(*) FROM tb_transaksi WHERE id_user=u.id_user) AS jml_transaksi
                                  FROM tb_user u ORDER BY u.role, u.nama");
?>
<?php include 'navbar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold mb-0"><i class="bi bi-people me-2 text-primary"></i>Manajemen Pengguna</h4>
</div>

<?= $pesan ?>

<div class="row g-4">
    <!-- FORM -->
    <div class="col-md-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white fw-semibold">
                <?= $edit['id_user'] ? '<i class="bi bi-pencil me-1"></i>Edit Pengguna' : '<i class="bi bi-person-plus me-1"></i>Tambah Pengguna' ?>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="id" value="<?= $edit['id_user'] ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control"
                               value="<?= htmlspecialchars($edit['nama']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Username</label>
                        <input type="text" name="username" class="form-control"
                               value="<?= htmlspecialchars($edit['username']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">
                            Password <?= $edit['id_user'] ? '<small class="text-muted">(kosongkan jika tidak diganti)</small>' : '' ?>
                        </label>
                        <input type="password" name="password" class="form-control"
                               <?= $edit['id_user'] ? '' : 'required' ?>>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Role</label>
                        <select name="role" class="form-select">
                            <option value="customer" <?= $edit['role'] === 'customer' ? 'selected' : '' ?>>Customer</option>
                            <option value="admin"    <?= $edit['role'] === 'admin'    ? 'selected' : '' ?>>Admin</option>
                        </select>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="simpan" class="btn btn-primary flex-fill">
                            <i class="bi bi-save me-1"></i> Simpan
                        </button>
                        <?php if ($edit['id_user']): ?>
                            <a href="admin_user.php" class="btn btn-outline-secondary">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- TABEL -->
    <div class="col-md-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white border-0 pt-3">
                <h6 class="fw-bold mb-0">Daftar Pengguna</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Transaksi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; while ($r = mysqli_fetch_assoc($users)): ?>
                            <tr <?= $edit['id_user'] == $r['id_user'] ? 'class="table-warning"' : '' ?>>
                                <td><?= $no++ ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($r['nama']) ?></td>
                                <td><code><?= htmlspecialchars($r['username']) ?></code></td>
                                <td>
                                    <span class="badge <?= $r['role'] === 'admin' ? 'bg-danger' : 'bg-info' ?>">
                                        <?= ucfirst($r['role']) ?>
                                    </span>
                                </td>
                                <td><span class="badge bg-secondary"><?= $r['jml_transaksi'] ?>x</span></td>
                                <td>
                                    <a href="?edit=<?= $r['id_user'] ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php if ((int)$r['id_user'] !== (int)$_SESSION['id_user']): ?>
                                    <a href="?hapus=<?= $r['id_user'] ?>" class="btn btn-danger btn-sm"
                                       onclick="return confirm('Hapus pengguna <?= htmlspecialchars($r['nama']) ?>?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
