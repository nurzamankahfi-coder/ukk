<?php
// ============================================================
// login.php — Halaman Login
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';

// Jika sudah login, redirect sesuai role
if (isset($_SESSION['id_user'])) {
    header("Location: " . ($_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'pesan_tiket.php'));
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(mysqli_real_escape_string($koneksi, $_POST['username'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "Username dan password harus diisi.";
    } else {
        $q = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username = '$username' LIMIT 1");
        if ($q && mysqli_num_rows($q) === 1) {
            $user = mysqli_fetch_assoc($q);
            if (password_verify($password, $user['pass'])) {
                $_SESSION['id_user']  = $user['id_user'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['nama']     = $user['nama'];
                $_SESSION['role']     = $user['role'];

                $redirect = ($user['role'] === 'admin') ? 'admin_dashboard.php' : 'pesan_tiket.php';
                header("Location: $redirect");
                exit;
            } else {
                $error = "Username atau password salah.";
            }
        } else {
            $error = "Username tidak ditemukan.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login — Kolam Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 50%, #0369a1 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.25);
            width: 100%;
            max-width: 420px;
        }
        .login-header {
            background: linear-gradient(135deg, #0ea5e9, #0369a1);
            color: white;
            border-radius: 16px 16px 0 0;
            padding: 32px;
            text-align: center;
        }
        .login-header i { font-size: 3rem; margin-bottom: 8px; }
        .login-body { padding: 32px; }
        .btn-login {
            background: linear-gradient(135deg, #0ea5e9, #0369a1);
            border: none;
            border-radius: 8px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .btn-login:hover { opacity: 0.9; color: white; }
    </style>
</head>
<body>
<div class="login-card card">
    <div class="login-header">
        <i class="bi bi-water d-block"></i>
        <h4 class="fw-bold mb-1">Kolam Renang</h4>
        <small class="opacity-75">Sistem Pemesanan Tiket Online</small>
    </div>
    <div class="login-body">
        <?php if ($error): ?>
            <div class="alert alert-danger d-flex align-items-center gap-2 py-2">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="mb-3">
                <label class="form-label fw-semibold">Username</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" class="form-control"
                           placeholder="Masukkan username"
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control"
                           placeholder="Masukkan password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-login btn-primary w-100 py-2">
                <i class="bi bi-box-arrow-in-right me-1"></i> Masuk
            </button>
        </form>

        <hr class="my-4">
        <p class="text-center text-muted small mb-0">
            Belum punya akun?
            <a href="daftar.php" class="text-decoration-none fw-semibold">Daftar di sini</a>
        </p>
    </div>
</div>
</body>
</html>
