<?php
// ============================================================
// admin_dashboard.php — Dashboard Admin
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); exit;
}

$total_tiket     = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS c FROM tb_tiket"))['c'];
$total_transaksi = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS c FROM tb_transaksi"))['c'];
$total_customer  = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS c FROM tb_user WHERE role='customer'"))['c'];
$total_pendapatan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) AS s FROM tb_transaksi"))['s'] ?? 0;

// 5 transaksi terbaru
$recent = mysqli_query($koneksi,
    "SELECT t.*, u.nama AS nama_pembeli, k.kategori
     FROM tb_transaksi t
     JOIN tb_user  u ON t.id_user  = u.id_user
     JOIN tb_tiket k ON t.id_tiket = k.id_tiket
     ORDER BY t.id_transaksi DESC LIMIT 5");
?>
<?php include 'navbar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0"><i class="bi bi-speedometer2 me-2 text-primary"></i>Dashboard Admin</h4>
    <span class="text-muted small"><i class="bi bi-calendar3 me-1"></i><?= date('d F Y') ?></span>
</div>

<!-- Statistik Kartu -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-white" style="background:linear-gradient(135deg,#0ea5e9,#0369a1)">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="fs-2 fw-bold"><?= $total_transaksi ?></div>
                        <div class="small opacity-75">Total Transaksi</div>
                    </div>
                    <i class="bi bi-receipt fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-white" style="background:linear-gradient(135deg,#22c55e,#15803d)">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="fs-5 fw-bold">Rp <?= number_format($total_pendapatan, 0, ',', '.') ?></div>
                        <div class="small opacity-75">Total Pendapatan</div>
                    </div>
                    <i class="bi bi-cash-coin fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-white" style="background:linear-gradient(135deg,#f59e0b,#b45309)">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="fs-2 fw-bold"><?= $total_customer ?></div>
                        <div class="small opacity-75">Customer</div>
                    </div>
                    <i class="bi bi-people fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-white" style="background:linear-gradient(135deg,#8b5cf6,#5b21b6)">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="fs-2 fw-bold"><?= $total_tiket ?></div>
                        <div class="small opacity-75">Jenis Tiket</div>
                    </div>
                    <i class="bi bi-ticket-perforated fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Transaksi Terbaru -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center pt-3">
        <h6 class="fw-bold mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Transaksi Terbaru</h6>
        <a href="admin_transaksi.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Pembeli</th>
                        <th>Kategori Tiket</th>
                        <th>Jml</th>
                        <th>Total</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($r = mysqli_fetch_assoc($recent)): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['nama_pembeli']) ?></td>
                        <td><span class="badge bg-primary"><?= htmlspecialchars($r['kategori']) ?></span></td>
                        <td><?= $r['jml_tiket'] ?></td>
                        <td class="fw-semibold text-success">Rp <?= number_format($r['total_harga'], 0, ',', '.') ?></td>
                        <td><small class="text-muted"><?= !empty($r['tgl_pesan']) ? date('d/m/Y H:i', strtotime($r['tgl_pesan'])) : '<span class="text-muted">-</span>' ?></small></td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($total_transaksi === 0): ?>
                    <tr><td colspan="5" class="text-center text-muted py-3">Belum ada transaksi</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
