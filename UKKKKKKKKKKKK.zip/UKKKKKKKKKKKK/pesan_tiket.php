<?php
// ============================================================
// pesan_tiket.php — Form Pesan Tiket (Customer)
// ============================================================
session_start();
require_once __DIR__ . '/koneksi.php';
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php"); exit;
}
if ($_SESSION['role'] === 'admin') {
    header("Location: admin_dashboard.php"); exit;
}

$pesan_sukses = "";
$pesan_error  = "";

// Ambil semua tiket
$tiket_list = [];
$q = mysqli_query($koneksi, "SELECT * FROM tb_tiket ORDER BY harga ASC");
while ($r = mysqli_fetch_assoc($q)) $tiket_list[] = $r;

// Proses pemesanan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user   = (int) $_SESSION['id_user'];
    $id_tiket  = (int) $_POST['id_tiket'];
    $jml_tiket = (int) $_POST['jml_tiket'];

    if ($jml_tiket < 1 || $jml_tiket > 20) {
        $pesan_error = "Jumlah tiket harus antara 1 hingga 20.";
    } else {
        $q_tiket = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM tb_tiket WHERE id_tiket = $id_tiket"));
        if ($q_tiket) {
            $total = (int) $q_tiket['harga'] * $jml_tiket;
            mysqli_query($koneksi, "INSERT INTO tb_transaksi (id_user, id_tiket, jml_tiket, total_harga)
                                    VALUES ($id_user, $id_tiket, $jml_tiket, $total)");
            $pesan_sukses = "Pemesanan berhasil! <strong>" . $jml_tiket . " tiket " .
                            htmlspecialchars($q_tiket['kategori']) . "</strong> — Total: <strong>Rp " .
                            number_format($total, 0, ',', '.') . "</strong>";
        } else {
            $pesan_error = "Kategori tiket tidak ditemukan.";
        }
    }
}
?>
<?php include 'navbar.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-7">

        <!-- Harga Tiket Info -->
        <div class="mb-4">
            <h5 class="fw-bold mb-3"><i class="bi bi-info-circle me-2 text-primary"></i>Kategori Tiket Tersedia</h5>
            <div class="row g-2">
                <?php foreach ($tiket_list as $t): ?>
                <div class="col-6 col-md-3">
                    <div class="card border-primary border-opacity-25 text-center shadow-sm h-100">
                        <div class="card-body py-3">
                            <div class="fw-semibold text-primary small"><?= htmlspecialchars($t['kategori']) ?></div>
                            <div class="fs-5 fw-bold text-dark mt-1">Rp <?= number_format($t['harga'], 0, ',', '.') ?></div>
                            <?php if (!empty($t['deskripsi'])): ?>
                            <div class="text-muted" style="font-size:0.72rem;margin-top:4px"><?= htmlspecialchars($t['deskripsi']) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Form Pesan -->
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white fw-semibold">
                <i class="bi bi-ticket-perforated me-2"></i>Form Pemesanan Tiket
            </div>
            <div class="card-body p-4">
                <?php if ($pesan_sukses): ?>
                <div class="alert alert-success d-flex align-items-start gap-2">
                    <i class="bi bi-check-circle-fill fs-5 mt-1"></i>
                    <div><?= $pesan_sukses ?>
                        <br><a href="riwayat.php" class="alert-link small">Lihat riwayat pemesanan →</a>
                    </div>
                </div>
                <?php endif; ?>
                <?php if ($pesan_error): ?>
                <div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($pesan_error) ?></div>
                <?php endif; ?>

                <form method="POST" id="formPesan">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Kategori Tiket</label>
                        <select name="id_tiket" id="id_tiket" class="form-select" required onchange="hitungTotal()">
                            <option value="">— Pilih Kategori —</option>
                            <?php foreach ($tiket_list as $t): ?>
                            <option value="<?= $t['id_tiket'] ?>" data-harga="<?= $t['harga'] ?>">
                                <?= htmlspecialchars($t['kategori']) ?> — Rp <?= number_format($t['harga'], 0, ',', '.') ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Jumlah Tiket</label>
                        <input type="number" name="jml_tiket" id="jml_tiket" class="form-control"
                               min="1" max="20" value="1" required oninput="hitungTotal()">
                        <div class="form-text">Maksimal 20 tiket per transaksi.</div>
                    </div>

                    <!-- Preview Total -->
                    <div class="alert alert-info d-flex justify-content-between align-items-center py-2 mb-3" id="previewTotal" style="display:none!important">
                        <span><i class="bi bi-calculator me-2"></i>Estimasi Total:</span>
                        <strong id="totalText" class="fs-5 text-primary">Rp 0</strong>
                    </div>

                    <button type="submit" class="btn btn-success w-100 py-2 fw-semibold">
                        <i class="bi bi-bag-check me-1"></i> Pesan Sekarang
                    </button>
                </form>
            </div>
        </div>

    </div>
</div>

<script>
function hitungTotal() {
    const sel   = document.getElementById('id_tiket');
    const jml   = parseInt(document.getElementById('jml_tiket').value) || 0;
    const opt   = sel.options[sel.selectedIndex];
    const harga = opt ? parseInt(opt.dataset.harga || 0) : 0;
    const total = harga * jml;
    const preview = document.getElementById('previewTotal');
    const text    = document.getElementById('totalText');
    if (harga > 0 && jml > 0) {
        text.textContent = 'Rp ' + total.toLocaleString('id-ID');
        preview.style.removeProperty('display');
    } else {
        preview.style.setProperty('display', 'none', 'important');
    }
}
</script>

<?php include 'footer.php'; ?>
