<?php
// ============================================================
// admin_transaksi.php — Kelola Data Transaksi (Admin)
// CRUD: Create (tambah), Read (tampil), Update (edit), Delete (hapus)
// ============================================================
session_start();
require_once 'koneksi.php';

// Cek login & hak akses admin
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$pesan = "";

// ============================================================
// DELETE — Hapus transaksi berdasarkan id_transaksi di URL
// Contoh URL: admin_transaksi.php?hapus=5
// ============================================================
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus']; // (int) untuk keamanan, hindari SQL Injection
    mysqli_query($koneksi, "DELETE FROM tb_transaksi WHERE id_transaksi = $id");
    $pesan = "<div class='alert alert-success'>Transaksi berhasil dihapus.</div>";
}

// ============================================================
// UPDATE — Simpan perubahan data transaksi dari form edit
// Form dikirim dengan method POST, ada input hidden name="simpan"
// ============================================================
if (isset($_POST['simpan'])) {
    $id        = (int) $_POST['id'];
    $id_tiket  = (int) $_POST['id_tiket'];
    $jml_tiket = (int) $_POST['jml_tiket'];

    // Ambil harga tiket yang dipilih, lalu hitung total
    $q_tiket     = mysqli_query($koneksi, "SELECT harga FROM tb_tiket WHERE id_tiket = $id_tiket");
    $data_tiket  = mysqli_fetch_assoc($q_tiket);
    $total_harga = $data_tiket['harga'] * $jml_tiket;

    mysqli_query($koneksi,
        "UPDATE tb_transaksi
         SET id_tiket = $id_tiket, jml_tiket = $jml_tiket, total_harga = $total_harga
         WHERE id_transaksi = $id"
    );
    $pesan = "<div class='alert alert-success'>Transaksi berhasil diperbarui.</div>";
}

// ============================================================
// READ (untuk form edit) — Ambil 1 baris data transaksi
// Aktif jika URL mengandung ?edit=ID
// ============================================================
$edit = null;
if (isset($_GET['edit'])) {
    $id   = (int) $_GET['edit'];
    $q    = mysqli_query($koneksi,
        "SELECT t.*, u.nama AS nama_pembeli, k.kategori
         FROM tb_transaksi t
         JOIN tb_user  u ON t.id_user  = u.id_user
         JOIN tb_tiket k ON t.id_tiket = k.id_tiket
         WHERE t.id_transaksi = $id"
    );
    $edit = mysqli_fetch_assoc($q);
}

// Ambil semua pilihan tiket untuk dropdown form edit
$q_tiket_list = mysqli_query($koneksi, "SELECT * FROM tb_tiket ORDER BY kategori ASC");
$tiket_list   = [];
while ($row = mysqli_fetch_assoc($q_tiket_list)) {
    $tiket_list[] = $row;
}

// ============================================================
// READ (semua data) — Tampilkan seluruh transaksi di tabel
// JOIN tb_user dan tb_tiket agar nama dan kategori bisa ditampilkan
// ============================================================
$q_semua    = mysqli_query($koneksi,
    "SELECT t.*, u.nama AS nama_pembeli, k.kategori
     FROM tb_transaksi t
     JOIN tb_user  u ON t.id_user  = u.id_user
     JOIN tb_tiket k ON t.id_tiket = k.id_tiket
     ORDER BY t.id_transaksi DESC"
);

// Hitung total semua pendapatan
$q_total    = mysqli_query($koneksi, "SELECT SUM(total_harga) AS total FROM tb_transaksi");
$total_all  = mysqli_fetch_assoc($q_total)['total'] ?? 0;
?>
<?php include 'navbar.php'; ?>

<!-- ============================================================
     JUDUL HALAMAN & TOTAL PENDAPATAN
     ============================================================ -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-receipt me-2 text-primary"></i>Data Transaksi
    </h4>
    <span class="badge bg-success fs-6 px-3">
        Total Pendapatan: Rp <?= number_format($total_all, 0, ',', '.') ?>
    </span>
</div>

<!-- Pesan sukses / error -->
<?= $pesan ?>

<!-- ============================================================
     FORM EDIT — Hanya muncul kalau ada ?edit=ID di URL
     ============================================================ -->
<?php if ($edit): ?>
<div class="card shadow-sm border-warning mb-4">
    <div class="card-header bg-warning fw-bold">
        <i class="bi bi-pencil-square me-2"></i>Edit Transaksi
    </div>
    <div class="card-body">
        <!-- Form dikirim dengan method POST ke halaman yang sama -->
        <form method="POST" action="admin_transaksi.php">
            <!-- ID transaksi disimpan di hidden input agar tahu data mana yang diupdate -->
            <input type="hidden" name="id" value="<?= $edit['id_transaksi'] ?>">

            <!-- Nama pembeli tidak bisa diubah (disabled) -->
            <div class="mb-3">
                <label class="form-label fw-semibold">Nama Pembeli</label>
                <input type="text" class="form-control"
                       value="<?= htmlspecialchars($edit['nama_pembeli']) ?>" disabled>
            </div>

            <!-- Dropdown pilih kategori tiket -->
            <div class="mb-3">
                <label class="form-label fw-semibold">Kategori Tiket</label>
                <select name="id_tiket" class="form-select" required>
                    <?php foreach ($tiket_list as $t): ?>
                    <option value="<?= $t['id_tiket'] ?>"
                        <?= $t['id_tiket'] == $edit['id_tiket'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['kategori']) ?> — Rp <?= number_format($t['harga'], 0, ',', '.') ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Input jumlah tiket -->
            <div class="mb-3">
                <label class="form-label fw-semibold">Jumlah Tiket</label>
                <input type="number" name="jml_tiket" class="form-control"
                       min="1" max="100" value="<?= $edit['jml_tiket'] ?>" required>
            </div>

            <!-- Tombol simpan & batal -->
            <div class="d-flex gap-2">
                <button type="submit" name="simpan" class="btn btn-warning fw-semibold">
                    <i class="bi bi-save me-1"></i>Simpan Perubahan
                </button>
                <a href="admin_transaksi.php" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ============================================================
     TABEL DATA TRANSAKSI (READ)
     ============================================================ -->
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Nama Pembeli</th>
                        <th>Kategori Tiket</th>
                        <th>Jumlah</th>
                        <th>Total Harga</th>
                        <th>Tanggal Pesan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no    = 1;
                    $found = false;
                    // Loop ambil semua baris transaksi satu per satu
                    while ($r = mysqli_fetch_assoc($q_semua)):
                        $found = true;
                    ?>
                    <tr <?= ($edit && $edit['id_transaksi'] == $r['id_transaksi']) ? 'class="table-warning"' : '' ?>>
                        <td><?= $no++ ?></td>
                        <td class="fw-semibold"><?= htmlspecialchars($r['nama_pembeli']) ?></td>
                        <td><span class="badge bg-primary"><?= htmlspecialchars($r['kategori']) ?></span></td>
                        <td><?= $r['jml_tiket'] ?> tiket</td>
                        <td class="text-success fw-bold">Rp <?= number_format($r['total_harga'], 0, ',', '.') ?></td>
                        <td><small class="text-muted"><?= date('d/m/Y H:i', strtotime($r['tgl_pesan'])) ?></small></td>
                        <td>
                            <!-- Tombol EDIT — kirim id lewat URL (?edit=ID) -->
                            <a href="?edit=<?= $r['id_transaksi'] ?>"
                               class="btn btn-warning btn-sm" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <!-- Tombol HAPUS — kirim id lewat URL (?hapus=ID) -->
                            <a href="?hapus=<?= $r['id_transaksi'] ?>"
                               class="btn btn-danger btn-sm" title="Hapus"
                               onclick="return confirm('Yakin hapus transaksi ini?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>

                    <?php if (!$found): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                            Belum ada transaksi.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
