<?php
// ============================================================
// navbar.php — Navbar yang dipakai semua halaman
// ============================================================
if (session_status() === PHP_SESSION_NONE) session_start();
$role = $_SESSION['role'] ?? '';
$nama = $_SESSION['nama'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kolam Renang — Tiket Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        .navbar-brand { font-weight: 700; letter-spacing: 0.5px; }
        .navbar { background: linear-gradient(90deg, #0ea5e9, #0369a1) !important; }
        .navbar .nav-link, .navbar .navbar-brand { color: #fff !important; }
        .navbar .nav-link:hover { color: #bae6fd !important; }
        .nav-link.active { border-bottom: 2px solid #fff; }
        body { background-color: #f0f9ff; }
        .footer { background: #0369a1; color: #bae6fd; padding: 16px; text-align: center; font-size: 0.85rem; margin-top: 60px; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?= $role === 'admin' ? 'admin_dashboard.php' : 'pesan_tiket.php' ?>">
            <i class="bi bi-water me-1"></i> Kolam Renang
        </a>
        <button class="navbar-toggler border-light" type="button" data-bs-toggle="collapse"
                data-bs-target="#navMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php if ($role === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_dashboard.php' ? 'active fw-semibold' : '' ?>"
                           href="admin_dashboard.php"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_tiket.php' ? 'active fw-semibold' : '' ?>"
                           href="admin_tiket.php"><i class="bi bi-ticket-perforated me-1"></i>Tiket</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_transaksi.php' ? 'active fw-semibold' : '' ?>"
                           href="admin_transaksi.php"><i class="bi bi-receipt me-1"></i>Transaksi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_user.php' ? 'active fw-semibold' : '' ?>"
                           href="admin_user.php"><i class="bi bi-people me-1"></i>Pengguna</a>
                    </li>
                <?php elseif ($role === 'customer'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'pesan_tiket.php' ? 'active fw-semibold' : '' ?>"
                           href="pesan_tiket.php"><i class="bi bi-ticket me-1"></i>Pesan Tiket</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'riwayat.php' ? 'active fw-semibold' : '' ?>"
                           href="riwayat.php"><i class="bi bi-clock-history me-1"></i>Riwayat</a>
                    </li>
                <?php endif; ?>
            </ul>

            <?php if ($role): ?>
                <div class="d-flex align-items-center gap-2">
                    <span class="text-white opacity-75 small">
                        <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($nama) ?>
                        <span class="badge bg-white text-primary ms-1"><?= ucfirst($role) ?></span>
                    </span>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-box-arrow-right me-1"></i>Keluar
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="container mt-4">
