-- ========================================
-- DATABASE: db_kolam_renang
-- Sistem Pemesanan Tiket Kolam Renang
-- ========================================

CREATE DATABASE IF NOT EXISTS `db_kolam_renang` 
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `db_kolam_renang`;

-- ----------------------------------------
-- Tabel: tb_user (Admin & Customer)
-- ----------------------------------------
CREATE TABLE IF NOT EXISTS `tb_user` (
  `id_user`    INT AUTO_INCREMENT PRIMARY KEY,
  `nama`       VARCHAR(100) NOT NULL,
  `username`   VARCHAR(50)  NOT NULL UNIQUE,
  `pass`       VARCHAR(255) NOT NULL,
  `role`       ENUM('admin','customer') NOT NULL DEFAULT 'customer',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------
-- Tabel: tb_tiket (Kategori & Harga Tiket)
-- ----------------------------------------
CREATE TABLE IF NOT EXISTS `tb_tiket` (
  `id_tiket`  INT AUTO_INCREMENT PRIMARY KEY,
  `kategori`  VARCHAR(100) NOT NULL,
  `harga`     INT          NOT NULL,
  `deskripsi` VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------
-- Tabel: tb_transaksi (Riwayat Pemesanan)
-- ----------------------------------------
CREATE TABLE IF NOT EXISTS `tb_transaksi` (
  `id_transaksi` INT AUTO_INCREMENT PRIMARY KEY,
  `id_user`      INT NOT NULL,
  `id_tiket`     INT NOT NULL,
  `jml_tiket`    INT NOT NULL,
  `total_harga`  INT NOT NULL,
  `tgl_pesan`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`id_user`)  REFERENCES `tb_user`(`id_user`)  ON DELETE CASCADE,
  FOREIGN KEY (`id_tiket`) REFERENCES `tb_tiket`(`id_tiket`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------
-- Data Awal: User Admin
-- Password: admin123
-- ----------------------------------------
INSERT INTO `tb_user` (`nama`, `username`, `pass`, `role`) VALUES
('Administrator', 'admin', '$2y$10$TKh8H1.PfPcfUhXBWFWxLO6fDHJRMFHPNa.hW1oN3gFBo6X5Zg5Hq', 'admin');
-- Password hash di atas = "admin123"

-- ----------------------------------------
-- Data Awal: Kategori Tiket
-- ----------------------------------------
INSERT INTO `tb_tiket` (`kategori`, `harga`, `deskripsi`) VALUES
('Umum Dewasa',   15000, 'Tiket masuk kolam renang untuk dewasa (usia 13+)'),
('Umum Anak',     10000, 'Tiket masuk kolam renang untuk anak (usia 5-12 tahun)'),
('Membership',    80000, 'Tiket bulanan tanpa batas kunjungan'),
('Weekend',       20000, 'Tiket khusus hari Sabtu & Minggu');
