<?php
// ============================================================
// koneksi.php — Koneksi ke database MySQL
// ============================================================
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_kolam_renang";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("<div style='font-family:sans-serif;color:red;padding:20px;'>
            <strong>Koneksi database gagal!</strong><br>
            " . mysqli_connect_error() . "
         </div>");
}

mysqli_set_charset($koneksi, "utf8mb4");
